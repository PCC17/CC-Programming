﻿using System;
using System.IO;
using System.Linq;
using System.Net;

namespace Program
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            string[] lines = File.ReadAllLines("lvl2-4.inp");
            
            foreach (var asteroid in Asteroid.ReadAsteriodsFromLines(lines.ToList()))
            {
                if (asteroid.Matrix.getNumberOfCoveredFields() > 0)
                {
                    Console.WriteLine(asteroid.TimeStamp + " " + asteroid.Matrix.getNumberOfCoveredFields());
                }
            }
        }
    }
}