﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Program
{
    public class Matrix
    {
        private List<List<double>> fieldsList;

        public Matrix(List<List<double>> fieldsList)
        {
            this.fieldsList = fieldsList;
        }

        public List<List<double>> FieldsList    
        {
            get => fieldsList;
            set => fieldsList = value;
        }

        public double SumOfFields()
        {
            double sum = 0;
            foreach (var row in fieldsList)
            {
                foreach (var column in row)
                {
                    sum += column;
                }
            }
            return sum;
        }

        public int getNumberOfCoveredFields()
        {
            int sum = 0;
            foreach (var row in fieldsList)
            {
                foreach (var column in row)
                {
                    if (column != 0)
                        sum++;
                }
            }
            return sum;
        }
    }
}