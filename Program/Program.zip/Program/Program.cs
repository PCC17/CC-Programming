﻿using System;
using System.IO;
using System.Linq;
using System.Net;

namespace Program
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            string[] lines = File.ReadAllLines("lvl1-2.inp");
            
            foreach (var asteroid in Asteroid.ReadAsteriodsFromLines(lines.ToList()))
            {
                if (asteroid.Matrix.SumOfFields() > 0)
                {
                    Console.WriteLine(asteroid.TimeStamp);
                }
            }
        }
    }
}